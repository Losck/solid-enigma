﻿namespace SmsBomber.SmsService
{
    internal class SitesList
    {
        public bool Alpari = false;
        public bool FindClone = false;
        public bool Tinder = false;
        public bool Twitch = false;
        public bool Invitro = false;
        public bool Youla = false;
        public bool GuruTaxi = false;
    }
}
